package data.campaign.econ;

public class BoggledStationConstructionIDs {

    public static class BoggledStationConstructionIndustryIDs
    {
        public static final String ASTROPOLIS_STATION = "ASTROPOLIS_STATION";
        public static final String BOGGLED_STATION_EXPANSION = "BOGGLED_STATION_EXPANSION";
    }
}